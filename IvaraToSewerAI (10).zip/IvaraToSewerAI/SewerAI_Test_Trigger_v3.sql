
------------------------------------------------------------
-- Step 0: (Optional) Verify base data with your test query
-- only only 4 work classes 
--LTV - Video inspection of CB leads	209
--MHTV - Video insp. Manholes	211
--MTV - Mainline Video Inspection	215
--STV - Service Video Inspection	266
------------------------------------------------------------
--
SELECT
    workclass,
    workclassificationoi,
    uuid,
    workcategory
FROM mnt.workclassification
WHERE UPPER(workclass) IN (
    UPPER('MTV - Mainline Video Inspection'),
    UPPER('MHTV - Video insp. Manholes'),
    UPPER('LTV - Video inspection of CB leads'),
    UPPER('STV - Service Video Inspection')
)
OR UPPER(workclass) LIKE '%CCTV%'
ORDER BY workclass;

-- Run as MNT (or any account with SELECT on MNT tables)

SELECT
    a.WORKCLASSIFI_OI            AS work_class_classification_id,  -- avoid alias duplication
    a.wotasktitle                AS work_order_task_title,
    a.plndcompdate_dttm          AS request_completion_date,
    a.plndstrtdate_dttm          AS request_start_date,
    wo.wonumber                  AS work_orders_number,
    a.tasknumber                 AS work_order_task_number,
    a.workordertaskoi            AS work_order_task_oi,
    a.uuid                       AS work_order_task_uuid,
    wo.site_oi
FROM
    mnt.workordertask a
    LEFT JOIN mnt.workorders wo
        ON a.workorder_oi = wo.workordersoi
    LEFT JOIN mnt.workclassification wc
        ON wc.workclassificationoi = a.workclassifi_oi
WHERE
    a.WORKCLASSIFI_OI IN (209, 211, 215, 266)
    AND wo.site_oi = 58
    AND a.uuid = '30F83231AAFBB242832472846D7884F9'
   -- AND wo.wonumber = '269543'
   -- AND a.tasknumber = 1
   -- AND a.workordertaskoi = 2083600
    
ORDER BY
    a.createdate_dttm DESC;

------------------------------------------------------------
-- Step 1: Drop staging table if exists (CUSTOMERDATA)
------------------------------------------------------------

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE CUSTOMERDATA.EPSEWERAI_WOT_STG1';
EXCEPTION
    WHEN OTHERS THEN
        NULL; -- expected if first run
END;
/

------------------------------------------------------------
-- Step 2: Create staging table
------------------------------------------------------------
DROP TABLE CUSTOMERDATA.EPSEWERAI_WOT_STG1



CREATE TABLE CUSTOMERDATA.EPSEWERAI_WOT_STG1 (
    TASK_UUID           RAW(16)       NOT NULL,
    WOTASKTITLE         VARCHAR2(503),
    PLNDCOMPDATE_DTTM   DATE,
    PLNDSTRTDATE_DTTM   DATE,
    WORKCLASSIFI_OI     NUMBER,
    FEED_STATUS         VARCHAR2(50)
);


------------------------------------------------------------
-- Grants: allow MNT to write to staging
------------------------------------------------------------
GRANT INSERT ON CUSTOMERDATA.EPSEWERAI_WOT_STG1 TO MNT;
GRANT UPDATE ON CUSTOMERDATA.EPSEWERAI_WOT_STG1 TO MNT;
-- If you want to restrict updates to specific columns, use instead:
-- GRANT UPDATE (WOTASKTITLE, PLNDCOMPDATE_DTTM, PLNDSTRTDATE_DTTM, FEED_STATUS)
--   ON CUSTOMERDATA.EPSEWERAI_WOT_STG1 TO MNT;

------------------------------------------------------------
-- Indexes
------------------------------------------------------------
-- Optional: index FEED_STATUS for downstream filtering
CREATE INDEX CUSTOMERDATA.IX_EPSEWERAI_WOT_STG1_FEED_STATUS
  ON CUSTOMERDATA.EPSEWERAI_WOT_STG1 (FEED_STATUS);

-- If UUIDs are guaranteed unique, you may prefer:
CREATE UNIQUE INDEX CUSTOMERDATA.UX_EPSEWERAI_WOT_STG1_TASK_UUID
  ON CUSTOMERDATA.EPSEWERAI_WOT_STG1 (TASK_UUID);

------------------------------------------------------------
-- Quick sanity check (optional)
------------------------------------------------------------
SELECT COUNT(*) AS rowcount
FROM CUSTOMERDATA.EPSEWERAI_WOT_STG1;


-------------------------------------------------------
-- Trigger: INSERT + UPDATE for wotasktitle / planned dates
-- Upsert into CUSTOMERDATA.EPSEWERAI_WOT_STG1
-- The trigger TRG_WOT_TO_STG1 automatically syncs data from MNT.WORKORDERTASK into the staging table CUSTOMERDATA.EPSEWERAI_WOT_STG1 whenever:

-- A new Work Order Task is inserted, OR
-- Certain fields are updated:wotasktitle, plndcompdate_dttm, plndstrtdate_dttm
-- But — only if the work order belongs to:
-- site_oi = 58, and
-- workclassification IN (209, 211, 215, 266)
-- If those conditions aren't met, the trigger does nothing.
------------------------------------------------------------

--DROP TRIGGER TRG_WOT_TO_STG1

CREATE OR REPLACE TRIGGER TRG_WOT_TO_STG1
AFTER INSERT OR UPDATE OF
    wotasktitle,
    plndcompdate_dttm,
    plndstrtdate_dttm,
    workclassifi_oi
ON MNT.WORKORDERTASK
FOR EACH ROW
BEGIN
  MERGE INTO CUSTOMERDATA.EPSEWERAI_WOT_STG1 s
  USING (
    SELECT
      /* TASK_UUID is RAW(16) and NOT NULL in target table */
      :NEW.uuid               AS task_uuid,
      :NEW.wotasktitle        AS wotasktitle,
      :NEW.plndcompdate_dttm  AS plndcompdate_dttm,
      :NEW.plndstrtdate_dttm  AS plndstrtdate_dttm,
      :NEW.workclassifi_oi    AS workclassifi_oi
    FROM MNT.workorders wo
    WHERE wo.workordersoi = :NEW.workorder_oi
      AND wo.site_oi      = 58
      AND :NEW.workclassifi_oi IN (209, 211, 215, 266)
  ) src
  ON (s.task_uuid = src.task_uuid)

  WHEN MATCHED THEN
    UPDATE SET
      s.wotasktitle         = src.wotasktitle,
      s.plndcompdate_dttm   = src.plndcompdate_dttm,
      s.plndstrtdate_dttm   = src.plndstrtdate_dttm,
      s.workclassifi_oi     = src.workclassifi_oi,
      s.feed_status         = 'UPDATED'
    WHERE
          NVL(s.wotasktitle, '~') <> NVL(src.wotasktitle, '~')
       OR NVL(s.plndcompdate_dttm, DATE '1900-01-01')
          <> NVL(src.plndcompdate_dttm, DATE '1900-01-01')
       OR NVL(s.plndstrtdate_dttm, DATE '1900-01-01')
          <> NVL(src.plndstrtdate_dttm, DATE '1900-01-01')
       OR NVL(s.workclassifi_oi, -1)
          <> NVL(src.workclassifi_oi, -1)

  WHEN NOT MATCHED THEN
    INSERT (
      task_uuid,
      wotasktitle,
      plndcompdate_dttm,
      plndstrtdate_dttm,
      workclassifi_oi,
      feed_status
    )
    VALUES (
      src.task_uuid,
      src.wotasktitle,
      src.plndcompdate_dttm,
      src.plndstrtdate_dttm,
      src.workclassifi_oi,
      'NEW'
    );
END;
/


ALTER TRIGGER TRG_WOT_TO_STG1 ENABLE;

-- Enable server output to see messages
SET SERVEROUTPUT ON SIZE UNLIMITED;

------------------------------------------------------------
-- Show compilation errors (if any)
------------------------------------------------------------

-- Sanity check
SELECT * FROM CUSTOMERDATA.EPSEWERAI_WOT_STG1;



UPDATE CUSTOMERDATA.EPSEWERAI_WOT_STG1
SET    FEED_STATUS = 'NEW'
WHERE  TASK_UUID = HEXTORAW('EA4C02B11A16DA40A7235F82D4504278')

COMMIT;

UPDATE CUSTOMERDATA.EPSEWERAI_WOT_STG1
SET    FEED_STATUS = 'READ'
WHERE  TASK_UUID = HEXTORAW('E823BEF0E7AE7843A57872AC201D01FB')

COMMIT;

-- Check staging data (run in CUSTOMERDATA or any account with SELECT)
SELECT WOTASKTITLE, PLNDCOMPDATE_DTTM, PLNDSTRTDATE_DTTM, TASK_UUID, FEED_STATUS
FROM CUSTOMERDATA.EPSEWERAI_WOT_STG1
FETCH FIRST 50 ROWS ONLY;

-- Check source changes (run in MNT)
SELECT wotasktitle, plndcompdate_dttm, plndstrtdate_dttm, uuid, createdate_dttm
FROM mnt.workordertask
ORDER BY createdate_dttm DESC;


