------------------------------------------------------------
-- Step 0: (Optional) Verify base data with your test query
-- (Adjust wonumber/tasknumber as needed)
-- Test query you posted:
-- SELECT ... FROM mnt.workordertask ... WHERE wo.wonumber = '268109' AND a.tasknumber = 1;
-- Ivara 1 "Manhole" -> Pioneer ""
-- Ivara 2 "Catch Basin" -> Pioneer ""
-- Ivara 3 "Outfall" -> Pioneer ""
-- Ivara 4 "Service Connection" -> Pioneer ""
-- Ivara 5 "Storage Unit" -> Pioneer ""
-- Ivara 6 "Inlet Outlet" -> Pioneer ""
-- Ivara 7 "Storm Water Management Facility" -> Pioneer ""
-- Ivara 8 "Pipe" -> Pioneer "Mainline"
-- Ivara 9 "Pump Station" -> Pioneer ""
-- Ivara 10 "Unknown Facility" -> Pioneer ""
-- Ivara 11"Culvert" -> Pioneer ""
-- Ivara 12"Swale" -> Pioneer ""
-- Ivara 13"Control Structure" -> Pioneer ""
-- Ivara 14"LID" -> Pioneer ""
------------------------------------------------------------

--Good query to see the data first
    
SELECT
    /* Work order + task info */
    wo.wonumber
    || '.'
    || a.tasknumber           AS work_orders_number,
    a.wotasktitle             AS work_order_task_title,
    s.assetnumber             AS asset_number,
    a.longdescript            AS work_order_task_longdesc,

    /* Facility information */
    e1.epdrdrainagefacilityoi AS facilityoi,
    e1.facilityid             AS facility_id,
    e1.facilitytype           AS facility_type,
    
        /* PIPE TYPE */
    CASE
    WHEN e1.facilitytype = 10 THEN
    'Unknown Facility'
    WHEN e1.facilitytype = 1  THEN
    'Manhole'
    WHEN e1.facilitytype = 2  THEN
    'Catch Basin'
    WHEN e1.facilitytype = 4  THEN
    'Service Connection'
    ELSE
    ep1.pipetype
    END                       AS pip_type,

    /* FINAL PIPE_SEGMENT_REFERENCE LOGIC (priority order) */
    CASE
        /* 1. Manhole ? strip MH prefix */
    WHEN mh.manholeid IS NOT NULL THEN
    regexp_replace(
        mh.manholeid, '^MH', ''
    )

        /* 2. Catch Basin ? strip CB prefix */
    WHEN cb.catchbasinid IS NOT NULL THEN
    regexp_replace(
        cb.catchbasinid, '^CB', ''
    )

        /* 3. Unknown Facility ? strip starting U */
    WHEN e1.facilitytype = 10 THEN
    regexp_replace(
        upper(
            ep2.unknfacid
        ), '^U', ''
    )

        /* 4. WASS logic: keep segment before last dash */
    WHEN esc.wass_appid IS NOT NULL THEN
    substr(
        esc.wass_appid, 1, instr(
            esc.wass_appid, '-', - 1
        ) - 1
    )

        /* 5. Pipe logic */
    WHEN ep1.pipeid IS NULL THEN
    NULL
    WHEN upper(
        ep1.pipeid
    ) LIKE 'PIP%' THEN
    substr(
        ep1.pipeid, 4
    )
    WHEN upper(
        ep1.pipeid
    ) LIKE 'CBL%' THEN
    substr(
        ep1.pipeid, 4
    )
    ELSE
    ep1.pipeid
    END                       AS pipe_segment_reference,
    e.epdrfacility_oi,
    e.epdrfacilityworkhistoryoi,

    /* Up/Downstream pipe references */
    ep1.usfacilityid          AS upstream_id,
    ep1.dsfacilityid          AS downstream_id,


    /* UUIDs */
    a.uuid                    AS work_order_task_uuid,
    e.uuid                    AS dr_uuid,
    e.createdate_dttm,
    e.lastupdate_dttm

FROM
    mnt.workordertask                 a
    LEFT JOIN mnt.workorders                    wo ON a.workorder_oi = wo.workordersoi
    LEFT JOIN mnt.asset                         s ON a.asset_oi = s.assetoi

/* FacWorkHistory is REQUIRED, so inner join */
    JOIN customerdata.epdrfacworkhistory   e ON e.wotask_oi = a.workordertaskoi
    LEFT JOIN customerdata.epdrdrainfacility    e1 ON e.epdrfacility_oi = e1.epdrdrainagefacilityoi
    LEFT JOIN customerdata.epdrpipe             ep1 ON e1.epdrpipe_oi = ep1.epdrpipeoi
    LEFT JOIN customerdata.epdrunknfac          ep2 ON e1.epdrunknownf_oi = ep2.epdrunknownfacilityoi
    LEFT JOIN customerdata."EPDRSERVICECONNECT" esc ON esc.wass_appid = e1.facilityid
    LEFT JOIN customerdata.epdrmanhole          mh ON mh.manholeid = e1.facilityid
    LEFT JOIN customerdata.epdrcatchbasin       cb ON cb.catchbasinid = e1.facilityid
WHERE
    wo.site_oi = 58
    AND e1.facilitytype IN ( 1, 2, 4, 8, 10 )
    AND wo.wonumber = '274885'
ORDER BY
    e1.facilitytype,
    work_orders_number DESC,
    pipe_segment_reference DESC;

---------------------------------------------------------------------------------------------
-- Step 0: (Optional) Verify base data with your test query
-- (Adjust wonumber/tasknumber as needed)
-- Test query you posted:
-- SELECT ... FROM mnt.workordertask ... WHERE wo.wonumber = '268109' AND a.tasknumber = 1;
--Ivara 10 "Unknown Facility" &
--          "Unknown Facility Type" 4= "Pipe" -> Pioneer "Mainline" -> PACP
--          "Unknown Facility Type" 5= "Catch Basin Lead" -> Pioneer "Mainline" -> PACP
--          "Unknown Facility Type" 6= "Service - Sanitary" -> Pioneer "Lateral" -> PACP
--          "Unknown Facility Type" 7= "Service - Storm" -> Pioneer "Lateral" -> PACP
--          "Unknown Facility Type" 8= "Service - Water" -> Pioneer "Lateral" -> PACP
--          "Unknown Facility Type" 3= "Manhole" -> Pioneer "Maintenance Hole (Manhole)" -> MACP
--          "Unknown Facility Type" 2= "Catch Basin" -> Pioneer "Maintenance Hole (Manhole)" -> MACP

--PUT /Videos/PACP
--project_sid (work_order_task_uuid)
--inspectionid (dr_uuid)
--PO_Number (Asset_number)
--Additional_Info (work_order_task_longdesc)
--Pipe_Segment_Reference

----------------------------------------------------------------------------------------------


WITH base AS (
    SELECT
        /* Work order + task info */
        wo.wonumber || '.' || a.tasknumber           AS work_orders_number,
        a.wotasktitle                                AS work_order_task_title,
        s.assetnumber                                AS asset_number,
        a.longdescript                               AS work_order_task_longdesc,

        /* Facility information */
        e1.epdrdrainagefacilityoi                    AS facilityoi,
        e1.facilityid                                AS facility_id,
        e1.facilitytype                              AS facility_type,
        e.epdrfacility_oi,
        e.epdrfacilityworkhistoryoi,
        e.createdate_dttm,
        e.lastupdate_dttm,

        /* Added columns */
        ep1.material                                 AS material,       -- CUSTOMERDATA.EPDRPIPE.MATERIAL
        cb.shape                                     AS cover_shape,    -- CUSTOMERDATA.EPDRCATCHBASIN.SHAPE

        /* Access Type: CB or Pipe depending on type (including unknown mapping) */
        CASE
            WHEN e1.facilitytype = 2 THEN cb.wwtype
            WHEN e1.facilitytype = 8 THEN ep1.wwtype
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN cb.wwtype
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 4 THEN ep1.wwtype
            ELSE NULL
        END                                           AS access_type,

        /* PIPE TYPE (with expanded unknown-type mapping) */
        CASE
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 3 THEN 'Manhole'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN 'Catch Basin'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 4 THEN 'Pipe'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 5 THEN 'Catch Basin Lead'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 6 THEN 'Service - Sanitary'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 7 THEN 'Service - Storm'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 8 THEN 'Service - Water'
            WHEN e1.facilitytype = 1 THEN 'Manhole'
            WHEN e1.facilitytype = 2 THEN 'Catch Basin'
            WHEN e1.facilitytype = 4 THEN 'Service Connection'
            WHEN e1.facilitytype = 8 THEN 'Pipe'
            ELSE 'Unknown Facility'
        END                                           AS pip_type,

        /* Base pipe reference computed once */
        CASE
            WHEN e1.facilitytype = 10 THEN REGEXP_REPLACE(UPPER(ep2.unknfacid), '^U', '')
            WHEN esc.wass_appid IS NOT NULL THEN SUBSTR(esc.wass_appid, 1, INSTR(esc.wass_appid, '-', -1) - 1)
            WHEN ep1.pipeid IS NULL THEN NULL
            WHEN UPPER(ep1.pipeid) LIKE 'PIP%' THEN SUBSTR(ep1.pipeid, 4)
            WHEN UPPER(ep1.pipeid) LIKE 'CBL%' THEN SUBSTR(ep1.pipeid, 4)
            ELSE ep1.pipeid
        END                                           AS base_pipe_ref,

        /* Manhole number only for types 1, 2, or unknown mapped to 2/3 */
        CASE
            WHEN e1.facilitytype = 1 THEN REGEXP_REPLACE(e1.facilityid, '^MH', '')
            WHEN e1.facilitytype = 2 THEN REGEXP_REPLACE(e1.facilityid, '^CB', '')
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 3 THEN REGEXP_REPLACE(e1.facilityid, '^MH', '')
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN REGEXP_REPLACE(e1.facilityid, '^CB', '')
            ELSE NULL
        END                                           AS Manhole_Number,

        /* Pipe network */
        ep1.usfacilityid                              AS upstream_id,
        ep1.dsfacilityid                              AS downstream_id,

        /* UUIDs / flags */
        a.uuid                                        AS work_order_task_uuid,
        e.uuid                                        AS dr_uuid,
        ep2.unknfacType                               AS unknown_type,

        /* Inspection type (updated mapping per your rule) */
        CASE
            WHEN e1.facilitytype IN (1, 2) THEN 'MACP'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType IN (2, 3) THEN 'MACP'
            WHEN e1.facilitytype = 8 THEN 'PACP'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType IN (4, 5, 6, 7, 8) THEN 'PACP'
            WHEN e1.facilitytype = 4 THEN 'LACP'
            ELSE NULL
        END                                           AS inspection_type

    FROM mnt.workordertask a
    LEFT JOIN mnt.workorders wo
           ON a.workorder_oi = wo.workordersoi
    LEFT JOIN mnt.asset s
           ON a.asset_oi = s.assetoi
    JOIN customerdata.epdrfacworkhistory e
         ON e.wotask_oi = a.workordertaskoi
    LEFT JOIN customerdata.epdrdrainfacility e1
           ON e.epdrfacility_oi = e1.epdrdrainagefacilityoi
    LEFT JOIN customerdata.epdrpipe ep1
           ON e1.epdrpipe_oi = ep1.epdrpipeoi
    LEFT JOIN customerdata.epdrunknfac ep2
           ON e1.epdrunknownf_oi = ep2.epdrunknownfacilityoi
    LEFT JOIN customerdata."EPDRSERVICECONNECT" esc
           ON esc.wass_appid = e1.facilityid
    LEFT JOIN customerdata.epdrcatchbasin cb
           ON cb.catchbasinid = e1.facilityid
)
SELECT
    work_orders_number,
    work_order_task_title,
    asset_number,
    work_order_task_longdesc,

    facilityoi,
    facility_id,
    facility_type,
    epdrfacility_oi,
    epdrfacilityworkhistoryoi,
    createdate_dttm,
    lastupdate_dttm,

    material,
    cover_shape,
    access_type,
    pip_type,

    /* Pipe segment reference:
       - NULL for facility_type 1,2,4 and for unknown mapped to 2 or 3
       - else from base_pipe_ref
    */
    CASE
        WHEN facility_type IN (1, 2, 4) THEN NULL
        WHEN facility_type = 10 AND unknown_type IN (2, 3) THEN NULL
        ELSE base_pipe_ref
    END AS pipe_segment_reference,

    /* Lateral segment for Service Connection */
    CASE
        WHEN facility_type = 4 THEN base_pipe_ref
        ELSE NULL
    END AS lateral_segment_reference,

    Manhole_Number,
    upstream_id,
    downstream_id,
    work_order_task_uuid,
    dr_uuid,
    unknown_type,
    inspection_type
FROM base

ORDER BY
    facility_type,
    work_orders_number DESC;


    
------------------------------------------------------------
-- Step 1: Drop table if exists (safe handling)
BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE CUSTOMERDATA.EPSEWERAI_CR_INSPECT';
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Table could not be dropped: ' || SQLERRM);
END;
/
------------------------------------------------------------
-- Step 2: Create table in CUSTOMERDATA schema
--PUT /Videos/PACP
--PUT /Videos/MACP
--PUT /Videos/LACP
--project_sid (work_order_task_uuid)
--inspectionid (dr_uuid)
--PO_Number (Asset_number)
--Additional_Info (work_order_task_longdesc)
--Pipe_Segment_Reference
-- CUSTOMERDATA schema
--TRUNCATE TABLE customerdata.epsewerai_cr_inspect
CREATE TABLE customerdata.epsewerai_cr_inspect (
    project_sid               RAW(16),             -- mnt.workordertask.uuid
    inspection_type           VARCHAR2(5 BYTE),    -- pacp, lacp, macp
    inspectionid              RAW(16),             -- CUSTOMERDATA.EPDRDRAINFACILITY.uuid
    workorder                 VARCHAR2(15 BYTE),   -- mnt.workorders.WONUMBER || '.' || mnt.workordertask.TaskNumber
    project                   VARCHAR2(503 BYTE),  -- mnt.workordertask.WOTASKTITLE
    po_number                 VARCHAR2(50 BYTE),   -- mnt.asset.ASSETNUMBER
    additional_information    CLOB,                -- mnt.workordertask.longdescript
    pipe_segment_reference    VARCHAR2(15 BYTE),  -- CUSTOMERDATA.EPDRDRAINFACILITY.facilityid (Strips chars as requested)
    lateral_segment_reference VARCHAR2(15 BYTE),
    manhole_number            VARCHAR2(15 BYTE),
    material                  VARCHAR2(15 BYTE),
    access_type               VARCHAR2(15 BYTE),
    cover_shape               VARCHAR2(15 BYTE),
    upstream_mh               VARCHAR2(15 BYTE),  -- CUSTOMERDATA.epdrpipe.usfacilityid 
    downstream_mh             VARCHAR2(15 BYTE),  -- CUSTOMERDATA.epdrpipe.dsfacilityid 
    feed_status               VARCHAR2(50)         -- NEW, READ
);



-- Grant INSERT privilege to MNT schema so the trigger can write to the audit table
GRANT INSERT ON CUSTOMERDATA.EPSEWERAI_CR_INSPECT TO MNT;


-- Helpful for filtering by feed status
CREATE INDEX IDX_EPSEWERAI_CR_INSPECT_STATUS
  ON CUSTOMERDATA.EPSEWERAI_CR_INSPECT (UPPER(FEED_STATUS));

-- Optional: search by wonumber_task quickly
CREATE INDEX IDX_EPSEWERAI_CR_INSPECT_WONUM_TASK
  ON CUSTOMERDATA.EPSEWERAI_CR_INSPECT (workorder);



-- Enable server output to see messages
SET SERVEROUTPUT ON SIZE UNLIMITED;

-- Sanity check
SELECT * FROM CUSTOMERDATA.EPSEWERAI_CR_INSPECT;
--TRUNCATE TABLE CUSTOMERDATA.EPSEWERAI_CR_INSPECT;

------------------------------------------------------------
-- Step 3: create a trigger insert into CUSTOMERDATA.EPSEWERAI_CR_INSPECT if TASK_UUID found at CUSTOMERDATA.EPSEWERAI_WOT_STG1 and FEED_STATUS  = 'SENT'.  

-- Drop old trigger (if exists)
DROP TRIGGER TRG_CR_INSPECT;
/

/*******************************************************************************************
 TRIGGER:  TR_EPDRFACWORKHIST_AI
 PURPOSE:  Inserts inspection?ready information into EPSEWERAI_CR_INSPECT staging table
           whenever a drainage facility work history record is created.
           
           Populate EPSEWERAI_CR_INSPECT when EPDRFACWORKHISTORY inserts occur.
           Uses a compound trigger to avoid mutating-table ORA?04091 errors.

 LOGIC SUMMARY:
   • Determines inspection type (PACP/MACP/LACP) using facility type + unknown facility rules
   • Determines pipe segment reference using priority sequence:
         1. Manhole IDs  (stripped of 'MH')
         2. Catch Basin IDs (stripped of 'CB')
         3. Unknown Facility IDs (stripped of 'U')
         4. Service Connection WASS_APPID prefix
         5. Pipe ID rules (strip PIP/CBL)
   • Prevents duplicate inserts per (TASK_UUID, DRUUID, PIPE_SEGMENT_REFERENCE)
   
 PROCESS:
     • BEFORE EACH ROW: store :NEW values in memory
     • AFTER STATEMENT: perform main SELECT/INSERT using stored keys
     • Includes full pipe-segment priority logic
     • Includes full inspection-type logic
     • Includes duplicate-prevention logic
 AUTHOR:   Cristina (Lau)
********************************************************************************************/

-- Create the new trigger
--DROP TRIGGER CUSTOMERDATA.TRG_FWH_TO_CR_INSPECT
CREATE OR REPLACE TRIGGER TRG_CR_INSPECT
FOR INSERT ON CUSTOMERDATA.EPDRFACWORKHISTORY
COMPOUND TRIGGER

  -- Row buffer (like your old script)
  TYPE t_key IS RECORD (
    wotask_oi        NUMBER,
    epdrfacility_oi  NUMBER,
    dr_uuid          VARCHAR2(50)   -- e.uuid text GUID; we'll hex->raw later
  );
  TYPE t_key_tab IS TABLE OF t_key;
  g_rows t_key_tab := t_key_tab();

  ------------------------------------------------------------------------------
  -- ROW LEVEL: buffer the minimal keys per inserted row
  ------------------------------------------------------------------------------
  BEFORE EACH ROW IS
  BEGIN
    g_rows.EXTEND;
    g_rows(g_rows.COUNT).wotask_oi       := :NEW.wotask_oi;
    g_rows(g_rows.COUNT).epdrfacility_oi := :NEW.epdrfacility_oi;
    g_rows(g_rows.COUNT).dr_uuid         := :NEW.uuid;
  END BEFORE EACH ROW;

  ------------------------------------------------------------------------------
  -- STATEMENT LEVEL: for each buffered key, insert the target row(s)
  ------------------------------------------------------------------------------
  AFTER STATEMENT IS
  BEGIN
    FOR i IN 1 .. g_rows.COUNT LOOP
      INSERT INTO CUSTOMERDATA.EPSEWERAI_CR_INSPECT (
        project_sid,                -- RAW(16) from a.uuid
        inspection_type,            -- 'PACP' | 'MACP' | 'LACP'
        inspectionid,               -- RAW(16): by default use e.uuid (DRUUID)
        workorder,                  -- wonumber||'.'||tasknumber (<=15)
        project,                    -- wotasktitle (<=503)
        po_number,                  -- assetnumber (<=50)
        additional_information,     -- longdescript (CLOB/VARCHAR2)
        pipe_segment_reference,     -- <=15 (per your priority rules)
        lateral_segment_reference,  -- <=15 (LACP-only case)
        manhole_number,             -- MH or CB stripped, else NULL
        material,                   -- ep1.material
        access_type,                -- cb.wwtype or ep1.wwtype per rules
        cover_shape,                -- cb.shape
        upstream_mh,                -- ep1.usfacilityid (<=15)
        downstream_mh,              -- ep1.dsfacilityid (<=15)
        feed_status                 -- 'NEW'
      )
      SELECT
        /* project_sid */
        HEXTORAW(REPLACE(a.uuid, '-', '')),

        /* inspection_type */
        CASE
          WHEN e1.facilitytype IN (1, 2) THEN 'MACP'
          WHEN e1.facilitytype = 10 AND ep2.unknfacType IN (2, 3) THEN 'MACP'
          WHEN e1.facilitytype = 8 THEN 'PACP'
          WHEN e1.facilitytype = 10 AND ep2.unknfacType IN (4, 5, 6, 7, 8) THEN 'PACP'
          WHEN e1.facilitytype = 4 THEN 'LACP'
          ELSE NULL
        END,

        /* inspectionid: use DR work-history UUID by default (old script semantics) */
        HEXTORAW(REPLACE(e.uuid, '-', '')),

        /* workorder (<=15) */
        SUBSTR(wo.wonumber || '.' || a.tasknumber, 1, 15),

        /* project (<=503) */
        SUBSTR(a.wotasktitle, 1, 503),

        /* po_number (<=50) */
        SUBSTR(s.assetnumber, 1, 50),

        /* additional_information */
        a.longdescript,

        /* pipe_segment_reference (priority rules, <=15) */
        CASE
          WHEN e1.facilitytype IN (1,2,4) THEN NULL
          WHEN e1.facilitytype = 10 AND ep2.unknfacType IN (2, 3) THEN NULL
          ELSE SUBSTR(
                 CASE
                   WHEN e1.facilitytype = 10 THEN REGEXP_REPLACE(UPPER(ep2.unknfacid), '^U', '')
                   WHEN esc.wass_appid IS NOT NULL
                        THEN SUBSTR(esc.wass_appid, 1, INSTR(esc.wass_appid, '-', -1) - 1)
                   WHEN ep1.pipeid IS NULL THEN NULL
                   WHEN UPPER(ep1.pipeid) LIKE 'PIP%' THEN SUBSTR(ep1.pipeid, 4)
                   WHEN UPPER(ep1.pipeid) LIKE 'CBL%' THEN SUBSTR(ep1.pipeid, 4)
                   ELSE ep1.pipeid
                 END, 1, 15)
        END,

        /* lateral_segment_reference (only for LACP) */
        CASE
          WHEN e1.facilitytype = 4 THEN
            SUBSTR(
              CASE
                WHEN e1.facilitytype = 10 THEN REGEXP_REPLACE(UPPER(ep2.unknfacid), '^U', '')
                WHEN esc.wass_appid IS NOT NULL THEN SUBSTR(esc.wass_appid, 1, INSTR(esc.wass_appid, '-', -1) - 1)
                WHEN ep1.pipeid IS NULL THEN NULL
                WHEN UPPER(ep1.pipeid) LIKE 'PIP%' THEN SUBSTR(ep1.pipeid, 4)
                WHEN UPPER(ep1.pipeid) LIKE 'CBL%' THEN SUBSTR(ep1.pipeid, 4)
                ELSE ep1.pipeid
              END, 1, 15)
          ELSE NULL
        END,

        /* manhole_number */
        CASE
          WHEN e1.facilitytype = 1 THEN REGEXP_REPLACE(e1.facilityid, '^MH', '')
          WHEN e1.facilitytype = 2 THEN REGEXP_REPLACE(e1.facilityid, '^CB', '')
          WHEN e1.facilitytype = 10 AND ep2.unknfacType = 3 THEN REGEXP_REPLACE(e1.facilityid, '^MH', '')
          WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN REGEXP_REPLACE(e1.facilityid, '^CB', '')
          ELSE NULL
        END,

        /* material */
        ep1.material,

        /* access_type */
        CASE
          WHEN e1.facilitytype = 2 THEN cb.wwtype
          WHEN e1.facilitytype = 8 THEN ep1.wwtype
          WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN cb.wwtype
          WHEN e1.facilitytype = 10 AND ep2.unknfacType = 4 THEN ep1.wwtype
          ELSE NULL
        END,

        /* cover_shape */
        cb.shape,

        /* upstream/downstream (<=15) */
        SUBSTR(ep1.usfacilityid, 1, 15),
        SUBSTR(ep1.dsfacilityid, 1, 15),

        /* feed_status */
        'NEW'
      FROM mnt.workordertask a
      JOIN customerdata.epdrfacworkhistory e
           ON e.wotask_oi = a.workordertaskoi
      LEFT JOIN mnt.workorders wo
           ON a.workorder_oi = wo.workordersoi
      LEFT JOIN mnt.asset s
           ON a.asset_oi = s.assetoi
      LEFT JOIN customerdata.epdrdrainfacility e1
           ON e.epdrfacility_oi = e1.epdrdrainagefacilityoi
      LEFT JOIN customerdata.epdrpipe ep1
           ON e1.epdrpipe_oi = ep1.epdrpipeoi
      LEFT JOIN customerdata.epdrunknfac ep2
           ON e1.epdrunknownf_oi = ep2.epdrunknownfacilityoi
      LEFT JOIN customerdata."EPDRSERVICECONNECT" esc
           ON esc.wass_appid = e1.facilityid
      LEFT JOIN customerdata.epdrcatchbasin cb
           ON cb.catchbasinid = e1.facilityid
      WHERE wo.site_oi = 58
        AND e.wotask_oi       = g_rows(i).wotask_oi
        AND e.epdrfacility_oi = g_rows(i).epdrfacility_oi
        -- If you MUST gate by staging FEED_STATUS='SENT', UNCOMMENT the block below:
        -- AND EXISTS (
        --       SELECT 1
        --       FROM CUSTOMERDATA.EPSEWERAI_WOT_STG1 stg
        --       WHERE stg.TASK_UUID = HEXTORAW(REPLACE(a.uuid, '-', ''))
        --         AND UPPER(stg.FEED_STATUS) = 'SENT'
        --     )
        AND NOT EXISTS (
              SELECT 1
              FROM CUSTOMERDATA.EPSEWERAI_CR_INSPECT t
              WHERE t.project_sid  = HEXTORAW(REPLACE(a.uuid, '-', ''))
                AND t.inspectionid = HEXTORAW(REPLACE(e.uuid, '-', ''))  -- match "inspectionid (dr_uuid)"
            );
    END LOOP;
  END AFTER STATEMENT;

END TRG_CR_INSPECT;
/

ALTER TRIGGER TRG_CR_INSPECT ENABLE;
/


-- Sanity check
SELECT * FROM CUSTOMERDATA.EPSEWERAI_CR_INSPECT;
